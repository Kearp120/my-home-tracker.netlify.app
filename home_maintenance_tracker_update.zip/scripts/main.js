document.addEventListener('DOMContentLoaded', () => {
    const taskContainer = document.getElementById('task-container');
    taskContainer.innerHTML = '<p>Loading tasks...</p>';

    fetch('/api/tasks')
        .then(response => response.json())
        .then(tasks => {
            taskContainer.innerHTML = '';
            if (tasks.length === 0) {
                taskContainer.innerHTML = '<p>No tasks available.</p>';
            } else {
                tasks.forEach(task => {
                    const taskItem = document.createElement('div');
                    taskItem.textContent = `${task.name} - Due: ${task.dueDate}`;
                    taskContainer.appendChild(taskItem);
                });
            }
        })
        .catch(error => {
            console.error('Error fetching tasks:', error);
            taskContainer.innerHTML = '<p>Failed to load tasks. Please try again later.</p>';
        });
});